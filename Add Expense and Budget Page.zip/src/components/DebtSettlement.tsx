import { useState } from 'react';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Button } from './ui/button';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from './ui/collapsible';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { ArrowRight, ChevronDown, Check, Clock, History } from 'lucide-react';

interface Settlement {
  from: string;
  fromName: string;
  fromColor: string;
  fromInitials: string;
  to: string;
  toName: string;
  toColor: string;
  toInitials: string;
  amount: number;
}

interface SettlementRecord {
  id: string;
  from: string;
  fromName: string;
  to: string;
  toName: string;
  amount: number;
  date: string;
  status: 'pending' | 'completed';
}

interface DebtSettlementProps {
  settlements: Settlement[];
  onRecordSettlement: (settlement: Settlement) => void;
  pendingSettlements: SettlementRecord[];
  completedSettlements: SettlementRecord[];
  onConfirmSettlement: (settlementId: string) => void;
  currentUserId: string;
}

export function DebtSettlement({ 
  settlements, 
  onRecordSettlement, 
  pendingSettlements,
  completedSettlements,
  onConfirmSettlement,
  currentUserId
}: DebtSettlementProps) {
  const [isOpen, setIsOpen] = useState(true);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);

  const pendingCount = pendingSettlements.filter(s => s.to === currentUserId).length;
  const allSettled = settlements.length === 0 && pendingSettlements.length === 0;

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200">
      {/* Main Settlement Summary */}
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <CollapsibleTrigger className="w-full px-6 py-4 flex items-center justify-between hover:bg-[#F5F5F7] transition-colors rounded-t-xl">
          <div>
            <div className="flex items-center gap-2">
              <h3>Settlement Summary</h3>
              {pendingCount > 0 && (
                <Badge variant="destructive" className="bg-orange-500 hover:bg-orange-600">
                  {pendingCount} pending
                </Badge>
              )}
            </div>
            <p className="text-muted-foreground text-sm mt-1">
              {allSettled 
                ? 'All expenses are settled!'
                : `${settlements.length + pendingSettlements.length} transaction${(settlements.length + pendingSettlements.length) !== 1 ? 's' : ''}`
              }
            </p>
          </div>
          <ChevronDown className={`w-5 h-5 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
        </CollapsibleTrigger>
        
        <CollapsibleContent>
          <div className="px-6 pb-4">
            {/* All Settled Message */}
            {allSettled && (
              <div className="flex items-center gap-2 text-green-600 p-4 bg-green-50 rounded-lg border border-green-200">
                <Check className="w-5 h-5" />
                <p>Everyone is even!</p>
              </div>
            )}

            {/* Pending Settlements */}
            {pendingSettlements.length > 0 && (
              <div className="space-y-2 mb-4">
                <div className="flex items-center gap-2 text-orange-600 mb-2">
                  <Clock className="w-4 h-4" />
                  <h4 className="text-sm">Pending Confirmations</h4>
                </div>
                {pendingSettlements.map((settlement) => {
                  const isReceiver = settlement.to === currentUserId;
                  return (
                    <div 
                      key={settlement.id}
                      className={`p-3 rounded-lg border ${
                        isReceiver 
                          ? 'bg-orange-50 border-orange-200' 
                          : 'bg-gray-50 border-gray-200'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-2 flex-1">
                          <span className="text-sm">
                            <span className="font-medium">{settlement.fromName}</span>
                            <ArrowRight className="w-3 h-3 inline mx-1" />
                            <span className="font-medium">{settlement.toName}</span>
                          </span>
                        </div>
                        
                        <span className="text-sm font-medium">${settlement.amount.toFixed(2)}</span>
                        
                        {isReceiver ? (
                          <Button
                            size="sm"
                            className="h-8 text-xs bg-green-600 hover:bg-green-700 text-white"
                            onClick={() => onConfirmSettlement(settlement.id)}
                          >
                            Confirm
                          </Button>
                        ) : (
                          <Badge variant="outline" className="text-xs border-orange-500 text-orange-600">
                            Pending
                          </Badge>
                        )}
                      </div>
                      {isReceiver && (
                        <p className="text-xs text-orange-700 mt-1">
                          Click confirm once you've received the payment
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {/* Outstanding Settlements to Record */}
            {settlements.length > 0 && (
              <div className="space-y-2">
                {pendingSettlements.length > 0 && <Separator className="my-4" />}
                <h4 className="text-sm text-muted-foreground mb-2">Outstanding Settlements</h4>
                {settlements.map((settlement, index) => (
                  <div 
                    key={index}
                    className="flex items-center gap-3 p-3 bg-[#F9F9FB] rounded-lg border border-gray-100"
                  >
                    <Avatar className="w-8 h-8">
                      <AvatarFallback className={`${settlement.fromColor} text-white text-xs`}>
                        {settlement.fromInitials}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-sm">{settlement.fromName}</span>
                    
                    <ArrowRight className="w-4 h-4 text-muted-foreground" />
                    
                    <Avatar className="w-8 h-8">
                      <AvatarFallback className={`${settlement.toColor} text-white text-xs`}>
                        {settlement.toInitials}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-sm">{settlement.toName}</span>
                    
                    <span className="ml-auto text-sm">${settlement.amount.toFixed(2)}</span>
                    
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-8 text-xs border-[#5B7FFF] text-[#5B7FFF] hover:bg-[#5B7FFF] hover:text-white"
                      onClick={() => onRecordSettlement(settlement)}
                      disabled={settlement.from !== currentUserId}
                    >
                      {settlement.from === currentUserId ? 'Record' : 'N/A'}
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </CollapsibleContent>
      </Collapsible>

      {/* Settlement History Section */}
      {completedSettlements.length > 0 && (
        <>
          <Separator />
          <Collapsible open={isHistoryOpen} onOpenChange={setIsHistoryOpen}>
            <CollapsibleTrigger className="w-full px-6 py-4 flex items-center justify-between hover:bg-[#F5F5F7] transition-colors rounded-b-xl">
              <div className="flex items-center gap-2">
                <History className="w-5 h-5 text-muted-foreground" />
                <div className="text-left">
                  <h3>Settlement History</h3>
                  <p className="text-muted-foreground text-sm mt-1">
                    {completedSettlements.length} completed settlement{completedSettlements.length !== 1 ? 's' : ''}
                  </p>
                </div>
              </div>
              <ChevronDown className={`w-5 h-5 transition-transform ${isHistoryOpen ? 'rotate-180' : ''}`} />
            </CollapsibleTrigger>
            
            <CollapsibleContent className="px-6 pb-4">
              <div className="space-y-2 pt-2">
                {completedSettlements.map((settlement) => (
                  <div 
                    key={settlement.id}
                    className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="text-sm">
                          <span className="font-medium">{settlement.fromName}</span>
                          <span className="text-muted-foreground"> paid </span>
                          <span className="font-medium">{settlement.toName}</span>
                        </p>
                        <Badge variant="outline" className="text-xs border-green-600 text-green-700 bg-green-100">
                          <Check className="w-3 h-3 mr-1" />
                          Completed
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        {new Date(settlement.date).toLocaleDateString('en-US', { 
                          month: 'short', 
                          day: 'numeric', 
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                    </div>
                    <span className="text-sm font-medium text-green-600">
                      ${settlement.amount.toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>
            </CollapsibleContent>
          </Collapsible>
        </>
      )}
    </div>
  );
}
