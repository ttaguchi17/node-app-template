import { Trash2, Edit } from 'lucide-react';
import { Button } from './ui/button';

interface ExpenseItemProps {
  expense: {
    id: string;
    description: string;
    amount: number;
    paidBy: string;
    date: string;
    category?: string;
    splits?: { personId: string; personName: string; amount: number }[];
  };
  onDelete?: (id: string) => void;
  onEdit?: (id: string) => void;
}

export function ExpenseItem({ expense, onDelete, onEdit }: ExpenseItemProps) {
  return (
    <div className="flex items-center justify-between p-4 bg-[#F9F9FB] border border-gray-100 rounded-lg hover:border-gray-200 transition-all">
      <div className="flex-1">
        <div className="flex items-center gap-3">
          <div>
            <p className="text-foreground">{expense.description}</p>
            <p className="text-muted-foreground text-sm">
              Paid by {expense.paidBy} • {expense.date}
            </p>
            {expense.splits && expense.splits.length > 0 && (
              <p className="text-muted-foreground text-sm mt-1">
                Split: {expense.splits.map(s => `${s.personName} ($${s.amount.toFixed(2)})`).join(', ')}
              </p>
            )}
          </div>
        </div>
      </div>
      
      <div className="flex items-center gap-4">
        <p className="text-foreground">${expense.amount.toFixed(2)}</p>
        <div className="flex gap-2">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 hover:bg-white"
            onClick={() => onEdit?.(expense.id)}
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-[#E53935] hover:text-[#E53935] hover:bg-red-50"
            onClick={() => onDelete?.(expense.id)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
