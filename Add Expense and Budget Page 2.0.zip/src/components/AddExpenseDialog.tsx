import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { X } from 'lucide-react';

interface AddExpenseDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAddExpense: (expense: {
    description: string;
    amount: number;
    paidBy: string;
    event: string;
    category: string;
    date: string;
    splits: { personId: string; amount: number }[];
  }) => void;
  people: { id: string; name: string }[];
  events: { id: string; name: string }[];
  currentUserId: string;
  editingExpense?: {
    id: string;
    description: string;
    amount: number;
    paidById: string;
    event: string;
    category?: string;
    date: string;
    splits: { personId: string; amount: number }[];
  } | null;
  onUpdateExpense?: (id: string, expense: {
    description: string;
    amount: number;
    paidBy: string;
    event: string;
    category: string;
    date: string;
    splits: { personId: string; amount: number }[];
  }) => void;
}

const CATEGORIES = [
  { id: 'accommodation', name: 'Accommodation', color: '#5B7FFF' },
  { id: 'transportation', name: 'Transportation', color: '#FF6B9D' },
  { id: 'food', name: 'Food', color: '#4CAF50' },
  { id: 'entertainment', name: 'Entertainment', color: '#FFA726' },
  { id: 'activities', name: 'Activities', color: '#AB47BC' },
  { id: 'shopping', name: 'Shopping', color: '#26C6DA' },
  { id: 'other', name: 'Other', color: '#78909C' },
];

export function AddExpenseDialog({ 
  open, 
  onOpenChange, 
  onAddExpense,
  people,
  events,
  currentUserId,
  editingExpense,
  onUpdateExpense
}: AddExpenseDialogProps) {
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [paidBy, setPaidBy] = useState('');
  const [date, setDate] = useState('');
  const [event, setEvent] = useState('other');
  const [category, setCategory] = useState('other');
  const [selectedPeople, setSelectedPeople] = useState<string[]>([]);
  const [splits, setSplits] = useState<{ [personId: string]: string }>({});
  const [splitEvenly, setSplitEvenly] = useState(true);
  const [manuallyEditedSplits, setManuallyEditedSplits] = useState<Set<string>>(new Set());

  // Reset form to defaults
  const resetForm = () => {
    setDescription('');
    setAmount('');
    setPaidBy(currentUserId || '');
    setDate(new Date().toISOString().split('T')[0]);
    setEvent('other');
    setCategory('other');
    setSelectedPeople(currentUserId ? [currentUserId] : []);
    setSplits({});
    setSplitEvenly(true);
    setManuallyEditedSplits(new Set());
  };

  // Set defaults when dialog opens or when editing
  useEffect(() => {
    if (open) {
      if (editingExpense) {
        // Populate form with existing expense data
        setDescription(editingExpense.description);
        setAmount(editingExpense.amount.toString());
        setPaidBy(editingExpense.paidById);
        setDate(editingExpense.date);
        setEvent(editingExpense.event);
        setCategory(editingExpense.category || 'other');
        setSelectedPeople(editingExpense.splits.map(s => s.personId));
        
        const initialSplits: { [personId: string]: string } = {};
        editingExpense.splits.forEach(split => {
          initialSplits[split.personId] = split.amount.toString();
        });
        setSplits(initialSplits);
        setSplitEvenly(false);
        setManuallyEditedSplits(new Set(editingExpense.splits.map(s => s.personId)));
      } else {
        // Reset to defaults when opening for new expense
        resetForm();
      }
    }
  }, [open, currentUserId, editingExpense]);

  // Auto-calculate even splits when amount or selected people change
  useEffect(() => {
    if (splitEvenly && amount && selectedPeople.length > 0) {
      const totalAmount = parseFloat(amount);
      if (!isNaN(totalAmount)) {
        const perPerson = (totalAmount / selectedPeople.length).toFixed(2);
        const newSplits: { [personId: string]: string } = {};
        selectedPeople.forEach(personId => {
          newSplits[personId] = perPerson;
        });
        setSplits(newSplits);
      }
    }
  }, [amount, selectedPeople, splitEvenly]);

  const handleAddPerson = (personId: string) => {
    if (!selectedPeople.includes(personId)) {
      const newSelectedPeople = [...selectedPeople, personId];
      setSelectedPeople(newSelectedPeople);
      
      if (splitEvenly && amount) {
        const totalAmount = parseFloat(amount);
        if (!isNaN(totalAmount)) {
          const perPerson = (totalAmount / newSelectedPeople.length).toFixed(2);
          const newSplits: { [personId: string]: string } = {};
          newSelectedPeople.forEach(pid => {
            newSplits[pid] = perPerson;
          });
          setSplits(newSplits);
        }
      } else {
        setSplits({ ...splits, [personId]: '0.00' });
      }
    }
  };

  const handleRemovePerson = (personId: string) => {
    const newSelectedPeople = selectedPeople.filter(id => id !== personId);
    setSelectedPeople(newSelectedPeople);
    
    const newSplits = { ...splits };
    delete newSplits[personId];
    setSplits(newSplits);
    
    if (splitEvenly && amount && newSelectedPeople.length > 0) {
      const totalAmount = parseFloat(amount);
      if (!isNaN(totalAmount)) {
        const perPerson = (totalAmount / newSelectedPeople.length).toFixed(2);
        const evenSplits: { [personId: string]: string } = {};
        newSelectedPeople.forEach(pid => {
          evenSplits[pid] = perPerson;
        });
        setSplits(evenSplits);
      }
    }
  };

  const handleSplitAmountChange = (personId: string, value: string) => {
    const newSplits = { ...splits, [personId]: value };
    setSplits(newSplits);
    
    // Mark this person's split as manually edited
    const newManuallyEdited = new Set(manuallyEditedSplits);
    newManuallyEdited.add(personId);
    setManuallyEditedSplits(newManuallyEdited);
    
    // Auto-calculate remaining splits if not split evenly
    if (!splitEvenly && amount && selectedPeople.length > 1) {
      const totalAmount = parseFloat(amount);
      if (!isNaN(totalAmount)) {
        // Calculate total of manually edited amounts
        let manualTotal = 0;
        const autoCalculatePeople: string[] = [];
        
        selectedPeople.forEach(pid => {
          if (newManuallyEdited.has(pid)) {
            const splitAmount = parseFloat(newSplits[pid] || '0');
            manualTotal += isNaN(splitAmount) ? 0 : splitAmount;
          } else {
            autoCalculatePeople.push(pid);
          }
        });
        
        // Distribute remaining amount equally among non-manually-edited people
        if (autoCalculatePeople.length > 0) {
          const remaining = totalAmount - manualTotal;
          const perPerson = (remaining / autoCalculatePeople.length).toFixed(2);
          
          autoCalculatePeople.forEach(pid => {
            newSplits[pid] = perPerson;
          });
          
          setSplits(newSplits);
        }
      }
    }
  };

  const getTotalSplit = () => {
    return Object.values(splits).reduce((sum, val) => {
      const num = parseFloat(val);
      return sum + (isNaN(num) ? 0 : num);
    }, 0);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!description || !amount || !paidBy || !date || selectedPeople.length === 0) {
      return;
    }

    const totalAmount = parseFloat(amount);
    const totalSplit = getTotalSplit();

    if (Math.abs(totalAmount - totalSplit) > 0.01) {
      alert('Split amounts must equal the total expense amount');
      return;
    }

    const expenseSplits = selectedPeople.map(personId => ({
      personId,
      amount: parseFloat(splits[personId] || '0'),
    }));

    if (editingExpense && onUpdateExpense) {
      onUpdateExpense(editingExpense.id, {
        description,
        amount: totalAmount,
        paidBy,
        event,
        category,
        date,
        splits: expenseSplits,
      });
    } else {
      onAddExpense({
        description,
        amount: totalAmount,
        paidBy,
        event,
        category,
        date,
        splits: expenseSplits,
      });
    }

    // Reset form
    resetForm();
    onOpenChange(false);
  };

  const availablePeople = people.filter(p => !selectedPeople.includes(p.id));
  const totalSplit = getTotalSplit();
  const totalAmount = parseFloat(amount) || 0;
  const splitDifference = totalAmount - totalSplit;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{editingExpense ? 'Edit Expense' : 'Add New Expense'}</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Input
              id="description"
              placeholder="e.g., Dinner at restaurant"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="amount">Amount ($)</Label>
            <Input
              id="amount"
              type="number"
              step="0.01"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="date">Date</Label>
            <Input
              id="date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="paidBy">Paid By</Label>
            <Select value={paidBy} onValueChange={setPaidBy} required>
              <SelectTrigger id="paidBy">
                <SelectValue placeholder="Select person" />
              </SelectTrigger>
              <SelectContent>
                {people.map((person) => (
                  <SelectItem key={person.id} value={person.id}>
                    {person.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="event">Event/Category</Label>
            <Select value={event} onValueChange={setEvent}>
              <SelectTrigger id="event">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="other">Other</SelectItem>
                {events.map((evt) => (
                  <SelectItem key={evt.id} value={evt.id}>
                    {evt.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">Category</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger id="category">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CATEGORIES.map((cat) => (
                  <SelectItem key={cat.id} value={cat.id}>
                    {cat.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* People to Share Expense With */}
          <div className="space-y-2">
            <Label>Share Expense With</Label>
            <div className="flex gap-2">
              <Select onValueChange={handleAddPerson} value="">
                <SelectTrigger className="flex-1">
                  <SelectValue placeholder="Add person to split..." />
                </SelectTrigger>
                <SelectContent>
                  {availablePeople.map((person) => (
                    <SelectItem key={person.id} value={person.id}>
                      {person.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Selected People with Split Amounts */}
            {selectedPeople.length > 0 && (
              <div className="border border-border rounded-lg p-4 space-y-3 bg-muted/30">
                <div className="flex items-center justify-between">
                  <p className="text-sm text-muted-foreground">Split Details</p>
                  {amount && (
                    <p className={`text-sm ${Math.abs(splitDifference) > 0.01 ? 'text-destructive' : 'text-muted-foreground'}`}>
                      Total: ${totalSplit.toFixed(2)} / ${totalAmount.toFixed(2)}
                    </p>
                  )}
                </div>

                {selectedPeople.map((personId) => {
                  const person = people.find(p => p.id === personId);
                  if (!person) return null;

                  const isAutoCalculated = !splitEvenly && !manuallyEditedSplits.has(personId);
                  
                  return (
                    <div key={personId} className="flex items-center gap-2">
                      <div className="flex-1">
                        <p className="text-sm">{person.name}</p>
                      </div>
                      <div className="w-32 relative">
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="0.00"
                          value={splits[personId] || ''}
                          onChange={(e) => handleSplitAmountChange(personId, e.target.value)}
                          disabled={splitEvenly}
                          className={`text-right ${isAutoCalculated ? 'bg-blue-50 border-blue-200' : ''}`}
                        />
                        {isAutoCalculated && (
                          <span className="absolute -top-1 -right-1 text-xs text-blue-600 bg-blue-100 px-1 rounded">auto</span>
                        )}
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleRemovePerson(personId)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  );
                })}

                <div className="flex items-center gap-2 pt-2 border-t border-border">
                  <Checkbox
                    id="splitEvenly"
                    checked={splitEvenly}
                    onCheckedChange={(checked) => {
                      setSplitEvenly(checked as boolean);
                      setManuallyEditedSplits(new Set());
                    }}
                  />
                  <Label htmlFor="splitEvenly" className="cursor-pointer">
                    Split evenly
                  </Label>
                </div>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={selectedPeople.length === 0 || Math.abs(splitDifference) > 0.01}
              className="bg-[#5B7FFF] hover:bg-[#4A6FEE] text-white"
            >
              {editingExpense ? 'Update Expense' : 'Add Expense'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}