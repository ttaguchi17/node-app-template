
  # Add Expense and Budget Page

  This is a code bundle for Add Expense and Budget Page. The original project is available at https://www.figma.com/design/FGxTVLMfaOeSw7uFZKKqO6/Add-Expense-and-Budget-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  