import { useState } from 'react';
import { SettlementBox } from './components/SettlementBox';

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="mb-6">Budgeting Dashboard</h1>
        <SettlementBox />
      </div>
    </div>
  );
}
