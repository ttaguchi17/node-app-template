import { useState } from 'react';
import { ChevronDown, ChevronUp, Check, X } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

interface Settlement {
  id: string;
  from: string;
  fromInitials: string;
  fromColor: string;
  to: string;
  toInitials: string;
  toColor: string;
  amount: number;
}

interface PendingApproval extends Settlement {
  timestamp: Date;
}

interface TransactionRecord extends Settlement {
  recordedAt: Date;
  approvedAt: Date;
}

export function SettlementBox() {
  const [outstandingOpen, setOutstandingOpen] = useState(true);
  const [recordsOpen, setRecordsOpen] = useState(false);
  
  const [outstandingSettlements, setOutstandingSettlements] = useState<Settlement[]>([
    {
      id: '1',
      from: 'Alex',
      fromInitials: 'AK',
      fromColor: 'bg-orange-500',
      to: 'Sarah',
      toInitials: 'SM',
      toColor: 'bg-blue-500',
      amount: 114.55
    },
    {
      id: '2',
      from: 'Jessica',
      fromInitials: 'JL',
      fromColor: 'bg-purple-500',
      to: 'Sarah',
      toInitials: 'SM',
      toColor: 'bg-blue-500',
      amount: 95.31
    },
    {
      id: '3',
      from: 'Mike',
      fromInitials: 'MI',
      fromColor: 'bg-green-500',
      to: 'Sarah',
      toInitials: 'SM',
      toColor: 'bg-blue-500',
      amount: 59.82
    }
  ]);

  const [pendingApprovals, setPendingApprovals] = useState<PendingApproval[]>([]);
  const [transactionRecords, setTransactionRecords] = useState<TransactionRecord[]>([]);

  const handleRecord = (settlement: Settlement) => {
    // Move to pending approvals
    const pending: PendingApproval = {
      ...settlement,
      timestamp: new Date()
    };
    setPendingApprovals([...pendingApprovals, pending]);
    
    // Show notification (simulated)
    alert(`Notification sent to ${settlement.to} to confirm receipt of $${settlement.amount.toFixed(2)} from ${settlement.from}`);
  };

  const handleApprove = (pending: PendingApproval) => {
    // Move to transaction records
    const record: TransactionRecord = {
      ...pending,
      recordedAt: pending.timestamp,
      approvedAt: new Date()
    };
    setTransactionRecords([record, ...transactionRecords]);
    
    // Remove from pending and outstanding
    setPendingApprovals(pendingApprovals.filter(p => p.id !== pending.id));
    setOutstandingSettlements(outstandingSettlements.filter(s => s.id !== pending.id));
  };

  const handleReject = (pending: PendingApproval) => {
    // Remove from pending approvals
    setPendingApprovals(pendingApprovals.filter(p => p.id !== pending.id));
    alert(`Payment rejected. ${pending.from} will be notified.`);
  };

  const totalOutstanding = outstandingSettlements.length + pendingApprovals.length;

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2>Settlement Summary</h2>
          <p className="text-gray-500">
            {totalOutstanding} {totalOutstanding === 1 ? 'transaction' : 'transactions'}
          </p>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setOutstandingOpen(!outstandingOpen)}
        >
          {outstandingOpen ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
        </Button>
      </div>

      {/* Outstanding Settlements Section */}
      {outstandingOpen && (
        <div className="space-y-4">
          <h3 className="text-gray-700">Outstanding Settlements</h3>
          
          {outstandingSettlements.map((settlement) => (
            <div
              key={settlement.id}
              className="flex items-center gap-4 p-3 rounded-lg hover:bg-gray-50 transition-colors"
            >
              {/* From Avatar */}
              <div className={`w-10 h-10 rounded-full ${settlement.fromColor} flex items-center justify-center text-white flex-shrink-0`}>
                {settlement.fromInitials}
              </div>
              
              {/* From Name */}
              <span className="min-w-[80px]">{settlement.from}</span>
              
              {/* Arrow */}
              <span className="text-gray-400">→</span>
              
              {/* To Avatar */}
              <div className={`w-10 h-10 rounded-full ${settlement.toColor} flex items-center justify-center text-white flex-shrink-0`}>
                {settlement.toInitials}
              </div>
              
              {/* To Name */}
              <span className="min-w-[80px]">{settlement.to}</span>
              
              {/* Spacer */}
              <div className="flex-1" />
              
              {/* Amount */}
              <span className="min-w-[80px] text-right">${settlement.amount.toFixed(2)}</span>
              
              {/* Record Button */}
              <Button
                variant="outline"
                size="sm"
                className="min-w-[90px]"
                onClick={() => handleRecord(settlement)}
              >
                Record
              </Button>
            </div>
          ))}

          {/* Pending Approvals */}
          {pendingApprovals.map((pending) => (
            <div
              key={`pending-${pending.id}`}
              className="flex items-center gap-4 p-3 rounded-lg bg-yellow-50 border border-yellow-200"
            >
              {/* From Avatar */}
              <div className={`w-10 h-10 rounded-full ${pending.fromColor} flex items-center justify-center text-white flex-shrink-0`}>
                {pending.fromInitials}
              </div>
              
              {/* From Name */}
              <span className="min-w-[80px]">{pending.from}</span>
              
              {/* Arrow */}
              <span className="text-gray-400">→</span>
              
              {/* To Avatar */}
              <div className={`w-10 h-10 rounded-full ${pending.toColor} flex items-center justify-center text-white flex-shrink-0`}>
                {pending.toInitials}
              </div>
              
              {/* To Name */}
              <span className="min-w-[80px]">{pending.to}</span>
              
              {/* Spacer */}
              <div className="flex-1" />
              
              {/* Amount */}
              <span className="min-w-[80px] text-right">${pending.amount.toFixed(2)}</span>
              
              {/* Pending Badge */}
              <Badge variant="outline" className="bg-yellow-100 border-yellow-300">
                Pending Approval
              </Badge>
              
              {/* Approval Actions */}
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleApprove(pending)}
                  className="text-green-600 hover:text-green-700 hover:bg-green-50"
                >
                  <Check className="w-4 h-4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleReject(pending)}
                  className="text-red-600 hover:text-red-700 hover:bg-red-50"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}

          {outstandingSettlements.length === 0 && pendingApprovals.length === 0 && (
            <p className="text-gray-400 text-center py-4">No outstanding settlements</p>
          )}
        </div>
      )}

      {/* Transaction Records Section */}
      {transactionRecords.length > 0 && (
        <div className="mt-6 pt-6 border-t border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <h3 className="text-gray-700">Transaction Records</h3>
              <Badge variant="secondary">{transactionRecords.length}</Badge>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setRecordsOpen(!recordsOpen)}
            >
              {recordsOpen ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
            </Button>
          </div>

          {recordsOpen && (
            <div className="space-y-3 max-h-[400px] overflow-y-auto">
              {transactionRecords.map((record, index) => (
                <div
                  key={`record-${record.id}-${index}`}
                  className="flex items-center gap-4 p-3 rounded-lg bg-green-50 border border-green-200"
                >
                  {/* From Avatar */}
                  <div className={`w-10 h-10 rounded-full ${record.fromColor} flex items-center justify-center text-white flex-shrink-0`}>
                    {record.fromInitials}
                  </div>
                  
                  {/* From Name */}
                  <span className="min-w-[80px]">{record.from}</span>
                  
                  {/* Arrow */}
                  <span className="text-gray-400">→</span>
                  
                  {/* To Avatar */}
                  <div className={`w-10 h-10 rounded-full ${record.toColor} flex items-center justify-center text-white flex-shrink-0`}>
                    {record.toInitials}
                  </div>
                  
                  {/* To Name */}
                  <span className="min-w-[80px]">{record.to}</span>
                  
                  {/* Spacer */}
                  <div className="flex-1" />
                  
                  {/* Amount */}
                  <span className="min-w-[80px] text-right">${record.amount.toFixed(2)}</span>
                  
                  {/* Completed Badge */}
                  <Badge variant="outline" className="bg-green-100 border-green-300 min-w-[100px] justify-center">
                    Completed
                  </Badge>
                  
                  {/* Date */}
                  <span className="text-gray-500 text-sm min-w-[100px] text-right">
                    {record.approvedAt.toLocaleDateString()}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
