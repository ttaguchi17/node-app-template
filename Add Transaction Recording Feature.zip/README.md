
  # Add Transaction Recording Feature

  This is a code bundle for Add Transaction Recording Feature. The original project is available at https://www.figma.com/design/AMThFmKcNsiiSk1qTBJhZN/Add-Transaction-Recording-Feature.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  