// Budgeting App Main JavaScript
class BudgetingApp {
    constructor() {
        this.trip = {
            name: "Santorini Getaway",
            totalBudget: 5000,
            members: [
                {
                    id: 1,
                    name: "Sarah Chen",
                    avatar: "resources/avatar1.jpg",
                    individualBudget: 1250,
                    spent: 0,
                    balance: 0
                },
                {
                    id: 2,
                    name: "Mike Johnson",
                    avatar: "resources/avatar2.jpg",
                    individualBudget: 1250,
                    spent: 0,
                    balance: 0
                },
                {
                    id: 3,
                    name: "Lisa Rodriguez",
                    avatar: "resources/avatar3.jpg",
                    individualBudget: 1250,
                    spent: 0,
                    balance: 0
                },
                {
                    id: 4,
                    name: "David Kim",
                    avatar: "resources/avatar4.jpg",
                    individualBudget: 1250,
                    spent: 0,
                    balance: 0
                }
            ],
            expenses: [],
            settlements: []
        };
        
        this.expenseCategories = [
            { name: 'Accommodation', icon: '🏨', color: '#3B82F6' },
            { name: 'Food & Dining', icon: '🍽️', color: '#10B981' },
            { name: 'Transportation', icon: '🚗', color: '#F59E0B' },
            { name: 'Activities', icon: '🎯', color: '#8B5CF6' },
            { name: 'Shopping', icon: '🛍️', color: '#EF4444' },
            { name: 'Other', icon: '📦', color: '#6B7280' }
        ];
        
        this.init();
    }

    init() {
        this.loadData();
        this.setupEventListeners();
        this.renderDashboard();
        this.initAnimations();
    }

    loadData() {
        const savedData = localStorage.getItem('budgetingApp');
        if (savedData) {
            const data = JSON.parse(savedData);
            this.trip = { ...this.trip, ...data };
        }
    }

    saveData() {
        localStorage.setItem('budgetingApp', JSON.stringify(this.trip));
    }

    setupEventListeners() {
        // Add expense modal
        const addExpenseBtn = document.getElementById('addExpenseBtn');
        if (addExpenseBtn) {
            addExpenseBtn.addEventListener('click', () => this.openAddExpenseModal());
        }

        // Settlement modal
        const settlementBtn = document.getElementById('settlementBtn');
        if (settlementBtn) {
            settlementBtn.addEventListener('click', () => this.openSettlementModal());
        }

        // Close modals
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal-overlay')) {
                this.closeModal();
            }
        });

        // Form submissions
        const expenseForm = document.getElementById('expenseForm');
        if (expenseForm) {
            expenseForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.addExpense();
            });
        }
    }

    renderDashboard() {
        this.updateTripSummary();
        this.renderMemberCards();
        this.renderRecentExpenses();
        this.renderAnalytics();
    }

    updateTripSummary() {
        const totalSpent = this.trip.expenses.reduce((sum, expense) => sum + expense.amount, 0);
        const remaining = this.trip.totalBudget - totalSpent;
        const budgetUsage = (totalSpent / this.trip.totalBudget) * 100;

        // Update summary cards
        const totalBudgetEl = document.getElementById('totalBudget');
        const totalSpentEl = document.getElementById('totalSpent');
        const remainingEl = document.getElementById('remaining');
        const budgetProgressEl = document.getElementById('budgetProgress');

        if (totalBudgetEl) totalBudgetEl.textContent = `$${this.trip.totalBudget.toLocaleString()}`;
        if (totalSpentEl) totalSpentEl.textContent = `$${totalSpent.toLocaleString()}`;
        if (remainingEl) remainingEl.textContent = `$${remaining.toLocaleString()}`;
        
        if (budgetProgressEl) {
            budgetProgressEl.style.width = `${Math.min(budgetUsage, 100)}%`;
            budgetProgressEl.className = `h-full rounded-full transition-all duration-1000 ${
                budgetUsage > 90 ? 'bg-red-500' : 
                budgetUsage > 75 ? 'bg-yellow-500' : 'bg-green-500'
            }`;
        }
    }

    renderMemberCards() {
        const container = document.getElementById('memberCards');
        if (!container) return;

        container.innerHTML = this.trip.members.map(member => {
            const memberExpenses = this.trip.expenses.filter(expense => 
                expense.paidBy === member.id || expense.splitWith.includes(member.id)
            );
            
            const spent = memberExpenses.reduce((sum, expense) => {
                if (expense.paidBy === member.id) {
                    return sum + expense.amount;
                } else {
                    const share = expense.amount / expense.splitWith.length;
                    return sum + share;
                }
            }, 0);
            
            const balance = member.individualBudget - spent;
            const usagePercent = (spent / member.individualBudget) * 100;

            return `
                <div class="member-card bg-white rounded-xl p-6 shadow-lg border border-gray-200 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                    <div class="flex items-center space-x-4 mb-4">
                        <img src="${member.avatar}" alt="${member.name}" 
                             class="w-16 h-16 rounded-full object-cover border-2 border-blue-500">
                        <div>
                            <h3 class="font-semibold text-gray-900">${member.name}</h3>
                            <p class="text-sm text-gray-600">Budget: $${member.individualBudget.toLocaleString()}</p>
                        </div>
                    </div>
                    
                    <div class="space-y-3">
                        <div class="flex justify-between items-center">
                            <span class="text-sm text-gray-600">Spent</span>
                            <span class="font-medium text-gray-900">$${spent.toFixed(2)}</span>
                        </div>
                        
                        <div class="w-full bg-gray-200 rounded-full h-2">
                            <div class="h-2 rounded-full transition-all duration-1000 ${
                                usagePercent > 90 ? 'bg-red-500' : 
                                usagePercent > 75 ? 'bg-yellow-500' : 'bg-green-500'
                            }" style="width: ${Math.min(usagePercent, 100)}%"></div>
                        </div>
                        
                        <div class="flex justify-between items-center">
                            <span class="text-sm text-gray-600">Balance</span>
                            <span class="font-bold ${balance >= 0 ? 'text-green-600' : 'text-red-600'}">
                                $${balance.toFixed(2)}
                            </span>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        // Animate member cards
        anime({
            targets: '.member-card',
            translateY: [50, 0],
            opacity: [0, 1],
            delay: anime.stagger(100),
            duration: 800,
            easing: 'easeOutExpo'
        });
    }

    renderRecentExpenses() {
        const container = document.getElementById('recentExpenses');
        if (!container) return;

        const recentExpenses = this.trip.expenses.slice(-5).reverse();
        
        if (recentExpenses.length === 0) {
            container.innerHTML = `
                <div class="text-center py-8 text-gray-500">
                    <p>No expenses yet. Add your first expense to get started!</p>
                </div>
            `;
            return;
        }

        container.innerHTML = recentExpenses.map(expense => {
            const category = this.expenseCategories.find(cat => cat.name === expense.category);
            const paidByMember = this.trip.members.find(m => m.id === expense.paidBy);
            
            return `
                <div class="expense-item bg-white rounded-lg p-4 shadow-sm border border-gray-100 hover:shadow-md transition-all duration-300">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center space-x-3">
                            <div class="w-10 h-10 rounded-full flex items-center justify-center text-lg"
                                 style="background-color: ${category?.color}20; color: ${category?.color}">
                                ${category?.icon}
                            </div>
                            <div>
                                <h4 class="font-medium text-gray-900">${expense.description}</h4>
                                <p class="text-sm text-gray-600">
                                    Paid by ${paidByMember?.name} • ${expense.splitWith.length} people
                                </p>
                            </div>
                        </div>
                        <div class="text-right">
                            <p class="font-semibold text-gray-900">$${expense.amount.toFixed(2)}</p>
                            <p class="text-sm text-gray-600">${expense.date}</p>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    }

    renderAnalytics() {
        const container = document.getElementById('analyticsChart');
        if (!container || typeof echarts === 'undefined') return;

        const chart = echarts.init(container);
        
        // Prepare data for category breakdown
        const categoryData = this.expenseCategories.map(category => {
            const categoryExpenses = this.trip.expenses.filter(expense => 
                expense.category === category.name
            );
            const totalAmount = categoryExpenses.reduce((sum, expense) => sum + expense.amount, 0);
            return {
                name: category.name,
                value: totalAmount,
                itemStyle: { color: category.color }
            };
        }).filter(item => item.value > 0);

        const option = {
            tooltip: {
                trigger: 'item',
                formatter: '{a} <br/>{b}: ${c} ({d}%)'
            },
            legend: {
                orient: 'vertical',
                left: 'left',
                textStyle: {
                    fontSize: 12
                }
            },
            series: [
                {
                    name: 'Expenses',
                    type: 'pie',
                    radius: ['40%', '70%'],
                    center: ['60%', '50%'],
                    avoidLabelOverlap: false,
                    label: {
                        show: false,
                        position: 'center'
                    },
                    emphasis: {
                        label: {
                            show: true,
                            fontSize: '18',
                            fontWeight: 'bold'
                        }
                    },
                    labelLine: {
                        show: false
                    },
                    data: categoryData,
                    animationType: 'scale',
                    animationEasing: 'elasticOut',
                    animationDelay: function (idx) {
                        return Math.random() * 200;
                    }
                }
            ]
        };

        chart.setOption(option);
    }

    openAddExpenseModal() {
        const modal = document.getElementById('expenseModal');
        if (!modal) return;

        // Render member selection
        const memberSelection = document.getElementById('memberSelection');
        if (memberSelection) {
            memberSelection.innerHTML = this.trip.members.map(member => `
                <label class="flex items-center space-x-3 p-3 rounded-lg border border-gray-200 hover:bg-gray-50 cursor-pointer">
                    <input type="checkbox" name="splitWith" value="${member.id}" 
                           class="w-4 h-4 text-blue-600 rounded focus:ring-blue-500">
                    <img src="${member.avatar}" alt="${member.name}" class="w-8 h-8 rounded-full object-cover">
                    <span class="text-sm font-medium text-gray-900">${member.name}</span>
                </label>
            `).join('');
        }

        // Render paid by selection
        const paidBySelect = document.getElementById('paidBy');
        if (paidBySelect) {
            paidBySelect.innerHTML = this.trip.members.map(member => 
                `<option value="${member.id}">${member.name}</option>`
            ).join('');
        }

        // Render category selection
        const categorySelect = document.getElementById('expenseCategory');
        if (categorySelect) {
            categorySelect.innerHTML = this.expenseCategories.map(category => 
                `<option value="${category.name}">${category.icon} ${category.name}</option>`
            ).join('');
        }

        modal.classList.remove('hidden');
        modal.classList.add('flex');
        
        // Animate modal
        anime({
            targets: '#expenseModal .modal-content',
            scale: [0.8, 1],
            opacity: [0, 1],
            duration: 300,
            easing: 'easeOutExpo'
        });
    }

    addExpense() {
        const form = document.getElementById('expenseForm');
        if (!form) return;

        const formData = new FormData(form);
        const amount = parseFloat(formData.get('amount'));
        const description = formData.get('description');
        const category = formData.get('category');
        const paidBy = parseInt(formData.get('paidBy'));
        const splitType = formData.get('splitType');
        
        // Get selected members for splitting
        const splitWith = Array.from(form.querySelectorAll('input[name="splitWith"]:checked'))
                              .map(input => parseInt(input.value));

        if (splitWith.length === 0) {
            alert('Please select at least one person to split with');
            return;
        }

        const expense = {
            id: Date.now(),
            amount,
            description,
            category,
            paidBy,
            splitType,
            splitWith: splitType === 'even' ? this.trip.members.map(m => m.id) : splitWith,
            date: new Date().toLocaleDateString()
        };

        this.trip.expenses.push(expense);
        this.saveData();
        this.closeModal();
        this.renderDashboard();
        
        // Show success message
        this.showNotification('Expense added successfully!', 'success');
    }

    openSettlementModal() {
        const modal = document.getElementById('settlementModal');
        if (!modal) return;

        const settlements = this.calculateSettlements();
        this.renderSettlementSummary(settlements);
        
        modal.classList.remove('hidden');
        modal.classList.add('flex');
        
        // Animate modal
        anime({
            targets: '#settlementModal .modal-content',
            scale: [0.8, 1],
            opacity: [0, 1],
            duration: 300,
            easing: 'easeOutExpo'
        });
    }

    calculateSettlements() {
        const balances = {};
        
        // Initialize balances
        this.trip.members.forEach(member => {
            balances[member.id] = 0;
        });

        // Calculate balances
        this.trip.expenses.forEach(expense => {
            const paidBy = expense.paidBy;
            const totalAmount = expense.amount;
            const splitCount = expense.splitWith.length;
            const sharePerPerson = totalAmount / splitCount;

            // Person who paid gets credit
            balances[paidBy] += totalAmount;

            // Everyone who splits owes their share
            expense.splitWith.forEach(memberId => {
                balances[memberId] -= sharePerPerson;
            });
        });

        // Optimize settlements
        const settlements = [];
        const creditors = [];
        const debtors = [];

        // Separate creditors and debtors
        Object.entries(balances).forEach(([memberId, balance]) => {
            if (balance > 0.01) {
                creditors.push({ memberId: parseInt(memberId), amount: balance });
            } else if (balance < -0.01) {
                debtors.push({ memberId: parseInt(memberId), amount: Math.abs(balance) });
            }
        });

        // Greedy settlement algorithm
        let i = 0, j = 0;
        while (i < debtors.length && j < creditors.length) {
            const debtor = debtors[i];
            const creditor = creditors[j];
            
            const amount = Math.min(debtor.amount, creditor.amount);
            
            settlements.push({
                from: debtor.memberId,
                to: creditor.memberId,
                amount: amount
            });

            debtor.amount -= amount;
            creditor.amount -= amount;

            if (debtor.amount < 0.01) i++;
            if (creditor.amount < 0.01) j++;
        }

        return settlements;
    }

    renderSettlementSummary(settlements) {
        const container = document.getElementById('settlementList');
        if (!container) return;

        if (settlements.length === 0) {
            container.innerHTML = `
                <div class="text-center py-8">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <span class="text-2xl">✅</span>
                    </div>
                    <h3 class="text-lg font-semibold text-gray-900 mb-2">All Settled!</h3>
                    <p class="text-gray-600">Everyone has paid their fair share. No settlements needed.</p>
                </div>
            `;
            return;
        }

        container.innerHTML = settlements.map((settlement, index) => {
            const fromMember = this.trip.members.find(m => m.id === settlement.from);
            const toMember = this.trip.members.find(m => m.id === settlement.to);
            
            return `
                <div class="settlement-item bg-white rounded-lg p-4 border border-gray-200 hover:shadow-md transition-all duration-300">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center space-x-3">
                            <div class="flex -space-x-2">
                                <img src="${fromMember?.avatar}" alt="${fromMember?.name}" 
                                     class="w-8 h-8 rounded-full border-2 border-white object-cover">
                                <img src="${toMember?.avatar}" alt="${toMember?.name}" 
                                     class="w-8 h-8 rounded-full border-2 border-white object-cover">
                            </div>
                            <div>
                                <p class="text-sm font-medium text-gray-900">
                                    ${fromMember?.name} → ${toMember?.name}
                                </p>
                                <p class="text-xs text-gray-600">Step ${index + 1} of ${settlements.length}</p>
                            </div>
                        </div>
                        <div class="text-right">
                            <p class="font-semibold text-blue-600">$${settlement.amount.toFixed(2)}</p>
                            <button class="text-xs text-green-600 hover:text-green-800 font-medium"
                                    onclick="budgetApp.markSettlementComplete(${index})">
                                Mark Complete
                            </button>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        // Animate settlement items
        anime({
            targets: '.settlement-item',
            translateX: [-50, 0],
            opacity: [0, 1],
            delay: anime.stagger(100),
            duration: 600,
            easing: 'easeOutExpo'
        });
    }

    markSettlementComplete(index) {
        // This would typically update the settlement status
        this.showNotification('Settlement marked as complete!', 'success');
    }

    closeModal() {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        });
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `fixed top-4 right-4 z-50 px-6 py-3 rounded-lg shadow-lg text-white transform translate-x-full transition-transform duration-300 ${
            type === 'success' ? 'bg-green-500' : 
            type === 'error' ? 'bg-red-500' : 'bg-blue-500'
        }`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Animate in
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        // Animate out and remove
        setTimeout(() => {
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }

    initAnimations() {
        // Animate dashboard elements on load
        anime({
            targets: '.dashboard-card',
            translateY: [30, 0],
            opacity: [0, 1],
            delay: anime.stagger(200),
            duration: 800,
            easing: 'easeOutExpo'
        });

        // Animate progress bars
        anime({
            targets: '.progress-bar',
            width: function(el) {
                return el.getAttribute('data-width') || '0%';
            },
            duration: 1500,
            easing: 'easeOutExpo',
            delay: 500
        });
    }

    // Split type toggle handler
    toggleSplitType(type) {
        const memberSelection = document.getElementById('memberSelection');
        const checkboxes = memberSelection?.querySelectorAll('input[name="splitWith"]');
        
        if (!checkboxes) return;

        if (type === 'even') {
            // Select all members for even split
            checkboxes.forEach(checkbox => {
                checkbox.checked = true;
                checkbox.disabled = true;
            });
            memberSelection.classList.add('opacity-50');
        } else {
            // Enable manual selection
            checkboxes.forEach(checkbox => {
                checkbox.disabled = false;
            });
            memberSelection.classList.remove('opacity-50');
        }
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.budgetApp = new BudgetingApp();
});

// Utility functions for HTML onclick handlers
function toggleSplitType(type) {
    window.budgetApp.toggleSplitType(type);
}

function closeModal() {
    window.budgetApp.closeModal();
}