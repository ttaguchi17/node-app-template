import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from './components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { Progress } from './components/ui/progress';
import { Avatar, AvatarFallback, AvatarImage } from './components/ui/avatar';
import { Badge } from './components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from './components/ui/dialog';
import { Input } from './components/ui/input';
import { Label } from './components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from './components/ui/select';
import { 
  Accordion, 
  AccordionContent, 
  AccordionItem, 
  AccordionTrigger 
} from './components/ui/accordion';
import { 
  Plus, 
  DollarSign, 
  Users, 
  TrendingUp, 
  TrendingDown, 
  CheckCircle, 
  Clock, 
  AlertCircle,
  Calculator,
  Receipt,
  ArrowRight,
  Download,
  Filter,
  Search,
  Edit2,
  Trash2,
  X
} from 'lucide-react';
import { toast } from 'sonner';

// TypeScript Interfaces
interface Person {
  id: string;
  name: string;
  avatar?: string;
  initials: string;
  color: string;
  hexColor: string;
  budget: number;
  email?: string;
}

interface ExpenseSplit {
  personId: string;
  amount: number;
  personName?: string;
}

interface Expense {
  id: string;
  description: string;
  amount: number;
  paidBy: string;
  paidById: string;
  date: string;
  event: string;
  category: string;
  splits: ExpenseSplit[];
  status: 'pending' | 'completed';
}

interface Settlement {
  id: string;
  from: string;
  fromName: string;
  to: string;
  toName: string;
  amount: number;
  date: string;
  status: 'pending' | 'completed';
}

interface Trip {
  id: string;
  name: string;
  people: Person[];
  events: { id: string; name: string }[];
  startDate: string;
  endDate: string;
  location: string;
}

// Expense Categories
const expenseCategories = [
  { id: 'accommodation', name: 'Accommodation', icon: '🏨', color: '#3B82F6' },
  { id: 'food', name: 'Food & Dining', icon: '🍽️', color: '#10B981' },
  { id: 'transport', name: 'Transportation', icon: '🚗', color: '#F59E0B' },
  { id: 'activities', name: 'Activities', icon: '🎯', color: '#8B5CF6' },
  { id: 'shopping', name: 'Shopping', icon: '🛍️', color: '#EF4444' },
  { id: 'other', name: 'Other', icon: '📦', color: '#6B7280' }
];

// Main Budget Page Component
export default function BudgetPage() {
  const navigate = useNavigate();
  const currentUserId = 'sarah'; // This would come from auth context
  
  // State Management
  const [trips, setTrips] = useState<Trip[]>([
    {
      id: 'trip-1',
      name: 'Santorini Getaway',
      people: [
        { 
          id: 'sarah', 
          name: 'Sarah Chen', 
          initials: 'SC', 
          color: 'bg-blue-500', 
          hexColor: '#3b82f6', 
          budget: 1250,
          avatar: '/resources/avatar1.jpg',
          email: 'sarah@example.com'
        },
        { 
          id: 'mike', 
          name: 'Mike Johnson', 
          initials: 'MJ', 
          color: 'bg-green-500', 
          hexColor: '#22c55e', 
          budget: 1250,
          avatar: '/resources/avatar2.jpg',
          email: 'mike@example.com'
        },
        { 
          id: 'lisa', 
          name: 'Lisa Rodriguez', 
          initials: 'LR', 
          color: 'bg-purple-500', 
          hexColor: '#a855f7', 
          budget: 1250,
          avatar: '/resources/avatar3.jpg',
          email: 'lisa@example.com'
        },
        { 
          id: 'david', 
          name: 'David Kim', 
          initials: 'DK', 
          color: 'bg-orange-500', 
          hexColor: '#f97316', 
          budget: 1250,
          avatar: '/resources/avatar4.jpg',
          email: 'david@example.com'
        }
      ],
      events: [
        { id: 'event-1', name: 'Hotel Stay' },
        { id: 'event-2', name: 'Wine Tour' },
        { id: 'event-3', name: 'Boat Excursion' },
      ],
      startDate: '2025-12-01',
      endDate: '2025-12-08',
      location: 'Santorini, Greece'
    }
  ]);

  const [selectedTripId, setSelectedTripId] = useState('trip-1');
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [settlements, setSettlements] = useState<Settlement[]>([]);
  
  // Modal States
  const [showAddExpense, setShowAddExpense] = useState(false);
  const [showSettlementModal, setShowSettlementModal] = useState(false);
  const [showBudgetEdit, setShowBudgetEdit] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [selectedPerson, setSelectedPerson] = useState<Person | null>(null);
  
  // Filter States
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [dateFilter, setDateFilter] = useState('all');
  const [sortBy, setSortBy] = useState('date');

  // Get current trip
  const currentTrip = trips.find(trip => trip.id === selectedTripId) || trips[0];

  // Calculate total budget
  const totalBudget = useMemo(() => {
    return currentTrip.people.reduce((sum, person) => sum + person.budget, 0);
  }, [currentTrip.people]);

  // Calculate spending per person
  const personSpending = useMemo(() => {
    return currentTrip.people.map(person => {
      const totalSpent = expenses.reduce((sum, expense) => {
        const split = expense.splits.find(s => s.personId === person.id);
        return sum + (split?.amount || 0);
      }, 0);

      return {
        id: person.id,
        name: person.name,
        amount: totalSpent,
        color: person.hexColor,
        budget: person.budget,
        percentage: (totalSpent / person.budget) * 100
      };
    });
  }, [currentTrip.people, expenses]);

  // Calculate total spent
  const totalSpent = useMemo(() => {
    return expenses.reduce((sum, expense) => sum + expense.amount, 0);
  }, [expenses]);

  // Calculate budget progress
  const budgetProgress = useMemo(() => {
    return (totalSpent / totalBudget) * 100;
  }, [totalSpent, totalBudget]);

  // Calculate settlements using minimum cash flow algorithm
  const calculatedSettlements = useMemo(() => {
    const balances: { [key: string]: number } = {};
    
    // Initialize balances
    currentTrip.people.forEach(person => {
      balances[person.id] = 0;
    });

    // Add what each person paid
    expenses.forEach(expense => {
      balances[expense.paidById] += expense.amount;
    });

    // Subtract what each person owes
    expenses.forEach(expense => {
      expense.splits.forEach(split => {
        balances[split.personId] -= split.amount;
      });
    });

    // Apply completed settlements
    settlements.filter(s => s.status === 'completed').forEach(settlement => {
      balances[settlement.from] += settlement.amount;
      balances[settlement.to] -= settlement.amount;
    });

    // Separate creditors and debtors
    const creditors: { id: string; amount: number }[] = [];
    const debtors: { id: string; amount: number }[] = [];

    Object.entries(balances).forEach(([personId, balance]) => {
      if (balance > 0.01) {
        creditors.push({ id: personId, amount: balance });
      } else if (balance < -0.01) {
        debtors.push({ id: personId, amount: -balance });
      }
    });

    // Sort by amount descending
    creditors.sort((a, b) => b.amount - a.amount);
    debtors.sort((a, b) => b.amount - a.amount);

    // Calculate minimum transactions
    const transactions: Settlement[] = [];
    let i = 0, j = 0;
    
    while (i < debtors.length && j < creditors.length) {
      const debtor = debtors[i];
      const creditor = creditors[j];
      const amount = Math.min(debtor.amount, creditor.amount);

      const debtorPerson = currentTrip.people.find(p => p.id === debtor.id)!;
      const creditorPerson = currentTrip.people.find(p => p.id === creditor.id)!;

      transactions.push({
        id: `settlement-${Date.now()}-${i}-${j}`,
        from: debtor.id,
        fromName: debtorPerson.name,
        to: creditor.id,
        toName: creditorPerson.name,
        amount,
        date: new Date().toISOString(),
        status: 'pending'
      });

      debtor.amount -= amount;
      creditor.amount -= amount;

      if (debtor.amount < 0.01) i++;
      if (creditor.amount < 0.01) j++;
    }

    return transactions;
  }, [currentTrip.people, expenses, settlements]);

  // Filter and sort expenses
  const filteredExpenses = useMemo(() => {
    let filtered = [...expenses];

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(expense => 
        expense.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        expense.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
        expense.paidBy.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Apply category filter
    if (categoryFilter !== 'all') {
      filtered = filtered.filter(expense => expense.category === categoryFilter);
    }

    // Apply sorting
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'amount':
          return b.amount - a.amount;
        case 'category':
          return a.category.localeCompare(b.category);
        case 'date':
        default:
          return new Date(b.date).getTime() - new Date(a.date).getTime();
      }
    });

    return filtered;
  }, [expenses, searchTerm, categoryFilter, sortBy]);

  // Group expenses by category
  const expensesByCategory = useMemo(() => {
    const grouped: { [key: string]: Expense[] } = {};
    
    filteredExpenses.forEach(expense => {
      if (!grouped[expense.category]) {
        grouped[expense.category] = [];
      }
      grouped[expense.category].push(expense);
    });

    return grouped;
  }, [filteredExpenses]);

  // Calculate category totals
  const categoryTotals = useMemo(() => {
    const totals: { [key: string]: number } = {};
    
    Object.entries(expensesByCategory).forEach(([category, expenses]) => {
      totals[category] = expenses.reduce((sum, expense) => sum + expense.amount, 0);
    });

    return totals;
  }, [expensesByCategory]);

  // Handlers
  const handleAddExpense = (expenseData: any) => {
    const newExpense: Expense = {
      id: `expense-${Date.now()}`,
      description: expenseData.description,
      amount: expenseData.amount,
      paidBy: expenseData.paidBy,
      paidById: expenseData.paidById,
      date: expenseData.date,
      event: expenseData.event,
      category: expenseData.category,
      splits: expenseData.splits,
      status: 'completed'
    };

    setExpenses([...expenses, newExpense]);
    toast.success('Expense added successfully!');
  };

  const handleUpdateExpense = (id: string, updatedExpense: any) => {
    setExpenses(expenses.map(exp => 
      exp.id === id ? { ...exp, ...updatedExpense } : exp
    ));
    toast.success('Expense updated successfully!');
  };

  const handleDeleteExpense = (id: string) => {
    setExpenses(expenses.filter(exp => exp.id !== id));
    toast.success('Expense deleted successfully!');
  };

  const handleRecordSettlement = (settlement: Settlement) => {
    setSettlements([...settlements, settlement]);
    toast.success('Settlement recorded successfully!');
  };

  const handleConfirmSettlement = (settlementId: string) => {
    setSettlements(settlements.map(s => 
      s.id === settlementId ? { ...s, status: 'completed' as const } : s
    ));
    toast.success('Settlement confirmed!');
  };

  const handleSaveBudget = (personId: string, newBudget: number) => {
    setTrips(trips.map(trip => {
      if (trip.id === selectedTripId) {
        return {
          ...trip,
          people: trip.people.map(person => 
            person.id === personId ? { ...person, budget: newBudget } : person
          ),
        };
      }
      return trip;
    }));
    toast.success('Budget updated successfully!');
  };

  const exportExpenses = () => {
    const csvContent = generateCSV(filteredExpenses);
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'trip-expenses.csv';
    a.click();
    window.URL.revokeObjectURL(url);
    toast.success('Expenses exported successfully!');
  };

  const generateCSV = (expenses: Expense[]) => {
    const headers = ['Description', 'Amount', 'Category', 'Paid By', 'Date', 'Split Type'];
    const rows = expenses.map(expense => {
      const splitPeople = expense.splits.map(s => 
        currentTrip.people.find(p => p.id === s.personId)?.name
      ).join('; ');
      
      return [
        expense.description,
        expense.amount,
        expense.category,
        expense.paidBy,
        expense.date,
        splitPeople
      ];
    });
    
    return [headers, ...rows].map(row => 
      row.map(field => `"${field}"`).join(',')
    ).join('\n');
  };

  // Initialize with sample data
  useEffect(() => {
    const sampleExpenses: Expense[] = [
      {
        id: '1',
        description: 'Hotel Booking - Santorini Resort',
        amount: 450.00,
        paidBy: 'Sarah Chen',
        paidById: 'sarah',
        date: '2025-12-01',
        event: 'event-1',
        category: 'accommodation',
        splits: [
          { personId: 'sarah', amount: 112.50 },
          { personId: 'mike', amount: 112.50 },
          { personId: 'lisa', amount: 112.50 },
          { personId: 'david', amount: 112.50 },
        ],
        status: 'completed'
      },
      {
        id: '2',
        description: 'Wine Tasting Experience',
        amount: 120.50,
        paidBy: 'Mike Johnson',
        paidById: 'mike',
        date: '2025-12-02',
        event: 'event-2',
        category: 'activities',
        splits: [
          { personId: 'sarah', amount: 30.13 },
          { personId: 'mike', amount: 30.13 },
          { personId: 'lisa', amount: 30.12 },
          { personId: 'david', amount: 30.12 },
        ],
        status: 'completed'
      },
      {
        id: '3',
        description: 'Sunset Boat Cruise',
        amount: 85.00,
        paidBy: 'Lisa Rodriguez',
        paidById: 'lisa',
        date: '2025-12-03',
        event: 'event-3',
        category: 'activities',
        splits: [
          { personId: 'sarah', amount: 21.25 },
          { personId: 'mike', amount: 21.25 },
          { personId: 'lisa', amount: 21.25 },
          { personId: 'david', amount: 21.25 },
        ],
        status: 'completed'
      },
      {
        id: '4',
        description: 'Group Dinner at Ammoudi Bay',
        amount: 65.75,
        paidBy: 'David Kim',
        paidById: 'david',
        date: '2025-12-04',
        event: 'other',
        category: 'food',
        splits: [
          { personId: 'sarah', amount: 16.44 },
          { personId: 'mike', amount: 16.44 },
          { personId: 'lisa', amount: 16.44 },
          { personId: 'david', amount: 16.43 },
        ],
        status: 'completed'
      }
    ];

    setExpenses(sampleExpenses);
  }, [currentTrip.people]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-bold text-gray-900">Trip Budget Manager</h1>
              <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                {currentTrip.name}
              </Badge>
            </div>
            <div className="flex items-center space-x-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowSettlementModal(true)}
                className="bg-green-50 text-green-700 border-green-200 hover:bg-green-100"
              >
                <Calculator className="w-4 h-4 mr-2" />
                Settlement
              </Button>
              <Button
                size="sm"
                onClick={() => setShowAddExpense(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Expense
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Budget Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-semibold flex items-center">
                <DollarSign className="w-5 h-5 mr-2" />
                Total Budget
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">${totalBudget.toLocaleString()}</p>
              <p className="text-blue-100 text-sm mt-1">
                {currentTrip.people.length} people • ${(totalBudget / currentTrip.people.length).toFixed(0)} each
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-red-500 to-red-600 text-white shadow-lg">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-semibold flex items-center">
                <TrendingDown className="w-5 h-5 mr-2" />
                Total Spent
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">${totalSpent.toLocaleString()}</p>
              <p className="text-red-100 text-sm mt-1">
                {budgetProgress.toFixed(1)}% of budget used
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white shadow-lg">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-semibold flex items-center">
                <TrendingUp className="w-5 h-5 mr-2" />
                Remaining
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">${(totalBudget - totalSpent).toLocaleString()}</p>
              <p className="text-green-100 text-sm mt-1">
                ${(totalBudget - totalSpent) / currentTrip.people.length:.0f} per person
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Budget Progress */}
        <Card className="mb-8 shadow-lg">
          <CardHeader>
            <CardTitle>Budget Usage Progress</CardTitle>
            <CardDescription>
              Overall trip budget consumption across all members
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Progress 
                value={budgetProgress} 
                className={`h-3 ${
                  budgetProgress > 90 ? 'bg-red-500' : 
                  budgetProgress > 75 ? 'bg-yellow-500' : 'bg-green-500'
                }`}
              />
              <div className="flex justify-between text-sm text-gray-600">
                <span>0%</span>
                <span className={`font-semibold ${
                  budgetProgress > 90 ? 'text-red-600' : 
                  budgetProgress > 75 ? 'text-yellow-600' : 'text-green-600'
                }`}>
                  {budgetProgress.toFixed(1)}%
                </span>
                <span>100%</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Member Overview */}
            <Card className="shadow-lg">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Trip Members</CardTitle>
                    <CardDescription>
                      Individual budgets and spending overview
                    </CardDescription>
                  </div>
                  <Users className="w-5 h-5 text-gray-400" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {currentTrip.people.map((person) => {
                    const spending = personSpending.find(p => p.id === person.id);
                    const budgetUsage = spending?.percentage || 0;
                    const isOverBudget = budgetUsage > 100;

                    return (
                      <div
                        key={person.id}
                        className="p-4 rounded-lg border border-gray-200 hover:shadow-md transition-all duration-200 cursor-pointer"
                        onClick={() => {
                          setSelectedPerson(person);
                          setShowBudgetEdit(true);
                        }}
                      >
                        <div className="flex items-center space-x-3 mb-3">
                          <Avatar className="h-12 w-12">
                            {person.avatar ? (
                              <AvatarImage src={person.avatar} alt={person.name} />
                            ) : (
                              <AvatarFallback className={`${person.color} text-white text-lg`}>
                                {person.initials}
                              </AvatarFallback>
                            )}
                          </Avatar>
                          <div>
                            <h3 className="font-semibold text-gray-900">{person.name}</h3>
                            <p className="text-sm text-gray-600">${person.budget.toLocaleString()} budget</p>
                          </div>
                        </div>
                        
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600">Spent</span>
                            <span className={`font-medium ${
                              isOverBudget ? 'text-red-600' : 'text-gray-900'
                            }`}>
                              ${spending?.amount.toFixed(2) || '0.00'}
                            </span>
                          </div>
                          
                          <Progress 
                            value={Math.min(budgetUsage, 100)} 
                            className={`h-2 ${
                              isOverBudget ? 'bg-red-500' : 
                              budgetUsage > 80 ? 'bg-yellow-500' : 'bg-green-500'
                            }`}
                          />
                          
                          <div className="flex justify-between text-xs text-gray-500">
                            <span>Balance</span>
                            <span className={`font-medium ${
                              (person.budget - (spending?.amount || 0)) >= 0 ? 'text-green-600' : 'text-red-600'
                            }`}>
                              ${(person.budget - (spending?.amount || 0)).toFixed(2)}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Expenses Section */}
            <Card className="shadow-lg">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Expense History</CardTitle>
                    <CardDescription>
                      All trip expenses organized by category
                    </CardDescription>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={exportExpenses}
                      className="bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Export
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {/* Filters */}
                <div className="flex flex-col sm:flex-row gap-4 mb-6">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <Input
                        placeholder="Search expenses..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                    <SelectTrigger className="w-full sm:w-32">
                      <SelectValue placeholder="Category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      {expenseCategories.map(cat => (
                        <SelectItem key={cat.id} value={cat.id}>
                          {cat.icon} {cat.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="w-full sm:w-32">
                      <SelectValue placeholder="Sort" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="date">Date</SelectItem>
                      <SelectItem value="amount">Amount</SelectItem>
                      <SelectItem value="category">Category</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Expenses List */}
                {filteredExpenses.length === 0 ? (
                  <div className="text-center py-12">
                    <Receipt className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No expenses found</h3>
                    <p className="text-gray-600 mb-4">
                      {searchTerm || categoryFilter !== 'all' 
                        ? 'Try adjusting your filters' 
                        : 'Add your first expense to get started'
                      }
                    </p>
                    <Button
                      onClick={() => {
                        setSearchTerm('');
                        setCategoryFilter('all');
                        setShowAddExpense(true);
                      }}
                      className="bg-blue-600 hover:bg-blue-700 text-white"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add Expense
                    </Button>
                  </div>
                ) : (
                  <Accordion type="multiple" className="space-y-2">
                    {Object.entries(expensesByCategory).map(([category, categoryExpenses]) => {
                      const categoryInfo = expenseCategories.find(c => c.id === category);
                      const total = categoryTotals[category] || 0;

                      return (
                        <AccordionItem key={category} value={category} className="border rounded-lg">
                          <AccordionTrigger className="px-4 py-3 hover:bg-gray-50">
                            <div className="flex items-center justify-between w-full">
                              <div className="flex items-center space-x-3">
                                <span className="text-2xl">{categoryInfo?.icon}</span>
                                <span className="font-medium">{categoryInfo?.name}</span>
                                <Badge variant="secondary" className="bg-gray-100 text-gray-700">
                                  {categoryExpenses.length}
                                </Badge>
                              </div>
                              <span className="font-semibold text-gray-900">
                                ${total.toFixed(2)}
                              </span>
                            </div>
                          </AccordionTrigger>
                          <AccordionContent className="px-4 pb-4">
                            <div className="space-y-3">
                              {categoryExpenses.map((expense) => (
                                <ExpenseCard
                                  key={expense.id}
                                  expense={expense}
                                  people={currentTrip.people}
                                  onEdit={() => {
                                    setEditingExpense(expense);
                                    setShowAddExpense(true);
                                  }}
                                  onDelete={() => handleDeleteExpense(expense.id)}
                                />
                              ))}
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      );
                    })}
                  </Accordion>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Stats */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Total Expenses</span>
                  <span className="font-semibold">{expenses.length}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Avg per Expense</span>
                  <span className="font-semibold">
                    ${expenses.length > 0 ? (totalSpent / expenses.length).toFixed(2) : '0.00'}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Pending Settlements</span>
                  <span className="font-semibold text-orange-600">
                    {calculatedSettlements.length}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Categories</span>
                  <span className="font-semibold">{Object.keys(expensesByCategory).length}</span>
                </div>
              </CardContent>
            </Card>

            {/* Settlement Summary */}
            {calculatedSettlements.length > 0 && (
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle>Settlement Plan</CardTitle>
                  <CardDescription>
                    Optimized payment plan ({calculatedSettlements.length} transactions)
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {calculatedSettlements.slice(0, 3).map((settlement) => (
                    <div key={settlement.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-2">
                        <Avatar className="h-8 w-8">
                          <AvatarFallback className="text-xs bg-gray-300 text-gray-700">
                            {settlement.fromName.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <ArrowRight className="w-4 h-4 text-gray-400" />
                        <Avatar className="h-8 w-8">
                          <AvatarFallback className="text-xs bg-gray-300 text-gray-700">
                            {settlement.toName.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                      </div>
                      <span className="font-semibold text-blue-600">
                        ${settlement.amount.toFixed(2)}
                      </span>
                    </div>
                  ))}
                  {calculatedSettlements.length > 3 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-full text-blue-600 hover:text-blue-700"
                      onClick={() => setShowSettlementModal(true)}
                    >
                      View All Settlements
                    </Button>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Top Spenders */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>Top Spenders</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {personSpending
                  .sort((a, b) => b.amount - a.amount)
                  .slice(0, 4)
                  .map((spender, index) => {
                    const person = currentTrip.people.find(p => p.id === spender.id);
                    return (
                      <div key={spender.id} className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="flex items-center justify-center w-6 h-6 rounded-full bg-gray-100 text-xs font-semibold text-gray-600">
                            {index + 1}
                          </div>
                          <Avatar className="h-8 w-8">
                            {person?.avatar ? (
                              <AvatarImage src={person.avatar} alt={person.name} />
                            ) : (
                              <AvatarFallback className={`${person?.color} text-white text-xs`}>
                                {person?.initials}
                              </AvatarFallback>
                            )}
                          </Avatar>
                          <span className="font-medium text-sm">{spender.name}</span>
                        </div>
                        <span className="font-semibold text-sm">
                          ${spender.amount.toFixed(2)}
                        </span>
                      </div>
                    );
                  })}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Modals */}
      <AddExpenseModal
        open={showAddExpense}
        onOpenChange={setShowAddExpense}
        onAddExpense={handleAddExpense}
        onUpdateExpense={handleUpdateExpense}
        people={currentTrip.people}
        editingExpense={editingExpense}
      />

      <SettlementModal
        open={showSettlementModal}
        onOpenChange={setShowSettlementModal}
        settlements={calculatedSettlements}
        people={currentTrip.people}
        onRecordSettlement={handleRecordSettlement}
        onConfirmSettlement={handleConfirmSettlement}
      />

      <BudgetEditModal
        open={showBudgetEdit}
        onOpenChange={setShowBudgetEdit}
        person={selectedPerson}
        onSave={handleSaveBudget}
      />
    </div>
  );
}

// Expense Card Component
function ExpenseCard({ expense, people, onEdit, onDelete }: {
  expense: Expense;
  people: Person[];
  onEdit: () => void;
  onDelete: () => void;
}) {
  const category = expenseCategories.find(c => c.id === expense.category);
  const paidByPerson = people.find(p => p.id === expense.paidById);
  const sharePerPerson = expense.amount / expense.splits.length;

  return (
    <div className="p-4 rounded-lg border border-gray-200 hover:shadow-md transition-all duration-200">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center space-x-3">
          <div 
            className="w-10 h-10 rounded-full flex items-center justify-center text-lg"
            style={{ backgroundColor: category?.color + '20', color: category?.color }}
          >
            {category?.icon}
          </div>
          <div>
            <h4 className="font-semibold text-gray-900">{expense.description}</h4>
            <p className="text-sm text-gray-600">
              Paid by {paidByPerson?.name} • {new Date(expense.date).toLocaleDateString()}
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-xl font-bold text-gray-900">${expense.amount.toFixed(2)}</span>
          <div className="flex space-x-1">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-gray-400 hover:text-blue-600"
              onClick={onEdit}
            >
              <Edit2 className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-gray-400 hover:text-red-600"
              onClick={onDelete}
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
      
      <div className="flex flex-wrap gap-2">
        {expense.splits.map((split, index) => {
          const person = people.find(p => p.id === split.personId);
          return (
            <span
              key={index}
              className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800"
            >
              {person?.name}: ${sharePerPerson.toFixed(2)}
            </span>
          );
        })}
      </div>
    </div>
  );
}

// Add Expense Modal
function AddExpenseModal({ open, onOpenChange, onAddExpense, onUpdateExpense, people, editingExpense }: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAddExpense: (expense: any) => void;
  onUpdateExpense?: (id: string, expense: any) => void;
  people: Person[];
  editingExpense: Expense | null;
}) {
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('other');
  const [paidBy, setPaidBy] = useState('');
  const [date, setDate] = useState('');
  const [selectedPeople, setSelectedPeople] = useState<string[]>([]);
  const [splits, setSplits] = useState<{ [personId: string]: string }>({});
  const [splitEvenly, setSplitEvenly] = useState(true);

  useEffect(() => {
    if (open) {
      if (editingExpense) {
        setDescription(editingExpense.description);
        setAmount(editingExpense.amount.toString());
        setCategory(editingExpense.category);
        setPaidBy(editingExpense.paidById);
        setDate(editingExpense.date);
        setSelectedPeople(editingExpense.splits.map(s => s.personId));
        
        const initialSplits: { [personId: string]: string } = {};
        editingExpense.splits.forEach(split => {
          initialSplits[split.personId] = split.amount.toString();
        });
        setSplits(initialSplits);
      } else {
        setDescription('');
        setAmount('');
        setCategory('other');
        setPaidBy(people[0]?.id || '');
        setDate(new Date().toISOString().split('T')[0]);
        setSelectedPeople(people.map(p => p.id));
        setSplits({});
        setSplitEvenly(true);
      }
    }
  }, [open, editingExpense, people]);

  // Auto-calculate even splits
  useEffect(() => {
    if (splitEvenly && amount && selectedPeople.length > 0) {
      const totalAmount = parseFloat(amount);
      if (!isNaN(totalAmount)) {
        const perPerson = (totalAmount / selectedPeople.length).toFixed(2);
        const newSplits: { [personId: string]: string } = {};
        selectedPeople.forEach(personId => {
          newSplits[personId] = perPerson;
        });
        setSplits(newSplits);
      }
    }
  }, [amount, selectedPeople, splitEvenly]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!description || !amount || !paidBy || !date || selectedPeople.length === 0) {
      toast.error('Please fill in all required fields');
      return;
    }

    const totalAmount = parseFloat(amount);
    const totalSplit = Object.values(splits).reduce((sum, val) => {
      const num = parseFloat(val);
      return sum + (isNaN(num) ? 0 : num);
    }, 0);

    if (Math.abs(totalAmount - totalSplit) > 0.01) {
      toast.error('Split amounts must equal the total expense amount');
      return;
    }

    const expenseSplits = selectedPeople.map(personId => ({
      personId,
      amount: parseFloat(splits[personId] || '0'),
    }));

    const expenseData = {
      description,
      amount: totalAmount,
      paidBy: people.find(p => p.id === paidBy)?.name || paidBy,
      paidById: paidBy,
      date,
      category,
      splits: expenseSplits,
    };

    if (editingExpense && onUpdateExpense) {
      onUpdateExpense(editingExpense.id, expenseData);
      toast.success('Expense updated successfully!');
    } else {
      onAddExpense(expenseData);
      toast.success('Expense added successfully!');
    }

    onOpenChange(false);
  };

  const availablePeople = people.filter(p => !selectedPeople.includes(p.id));
  const totalSplit = Object.values(splits).reduce((sum, val) => sum + (parseFloat(val) || 0), 0);
  const totalAmount = parseFloat(amount) || 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {editingExpense ? 'Edit Expense' : 'Add New Expense'}
          </DialogTitle>
          <DialogDescription>
            {editingExpense ? 'Update the expense details' : 'Record a new expense and split it among trip members'}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="description">Description *</Label>
              <Input
                id="description"
                placeholder="e.g., Dinner at restaurant"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount">Amount *</Label>
              <Input
                id="amount"
                type="number"
                step="0.01"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger id="category">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {expenseCategories.map(cat => (
                    <SelectItem key={cat.id} value={cat.id}>
                      {cat.icon} {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="date">Date *</Label>
              <Input
                id="date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="paidBy">Paid By *</Label>
            <Select value={paidBy} onValueChange={setPaidBy} required>
              <SelectTrigger id="paidBy">
                <SelectValue placeholder="Select person" />
              </SelectTrigger>
              <SelectContent>
                {people.map((person) => (
                  <SelectItem key={person.id} value={person.id}>
                    {person.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-4">
            <Label>Split With</Label>
            <div className="flex gap-2">
              <Select onValueChange={(personId) => {
                if (personId && !selectedPeople.includes(personId)) {
                  setSelectedPeople([...selectedPeople, personId]);
                }
              }} value="">
                <SelectTrigger className="flex-1">
                  <SelectValue placeholder="Add person to split..." />
                </SelectTrigger>
                <SelectContent>
                  {availablePeople.map((person) => (
                    <SelectItem key={person.id} value={person.id}>
                      {person.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedPeople.length > 0 && (
              <div className="border border-gray-200 rounded-lg p-4 space-y-3 bg-gray-50">
                <div className="flex items-center justify-between">
                  <p className="text-sm text-gray-600">Split Details</p>
                  {amount && (
                    <p className={`text-sm ${Math.abs(totalAmount - totalSplit) > 0.01 ? 'text-red-600' : 'text-gray-600'}`}>
                      Total: ${totalSplit.toFixed(2)} / ${totalAmount.toFixed(2)}
                    </p>
                  )}
                </div>

                {selectedPeople.map((personId) => {
                  const person = people.find(p => p.id === personId);
                  if (!person) return null;

                  return (
                    <div key={personId} className="flex items-center gap-3">
                      <Avatar className="h-8 w-8">
                        {person.avatar ? (
                          <AvatarImage src={person.avatar} alt={person.name} />
                        ) : (
                          <AvatarFallback className={`${person.color} text-white text-xs`}>
                            {person.initials}
                          </AvatarFallback>
                        )}
                      </Avatar>
                      <span className="flex-1 text-sm">{person.name}</span>
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="0.00"
                        value={splits[personId] || ''}
                        onChange={(e) => {
                          setSplits({ ...splits, [personId]: e.target.value });
                        }}
                        disabled={splitEvenly}
                        className="w-24 text-right"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-gray-400 hover:text-red-600"
                        onClick={() => {
                          setSelectedPeople(selectedPeople.filter(id => id !== personId));
                          const newSplits = { ...splits };
                          delete newSplits[personId];
                          setSplits(newSplits);
                        }}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  );
                })}

                <div className="flex items-center gap-2 pt-2 border-t border-gray-200">
                  <input
                    type="checkbox"
                    id="splitEvenly"
                    checked={splitEvenly}
                    onChange={(e) => setSplitEvenly(e.target.checked)}
                    className="rounded border-gray-300"
                  />
                  <Label htmlFor="splitEvenly" className="cursor-pointer text-sm">
                    Split evenly among selected people
                  </Label>
                </div>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={selectedPeople.length === 0 || Math.abs(totalAmount - totalSplit) > 0.01}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              {editingExpense ? 'Update Expense' : 'Add Expense'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

// Settlement Modal
function SettlementModal({ open, onOpenChange, settlements, people, onRecordSettlement, onConfirmSettlement }: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  settlements: Settlement[];
  people: Person[];
  onRecordSettlement: (settlement: Settlement) => void;
  onConfirmSettlement: (settlementId: string) => void;
}) {
  const handleMarkComplete = (settlement: Settlement) => {
    const completedSettlement = { ...settlement, status: 'completed' as const };
    onConfirmSettlement(settlement.id);
    onRecordSettlement(completedSettlement);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Settlement Summary</DialogTitle>
          <DialogDescription>
            Optimized payment plan to settle all debts with minimum transactions
          </DialogDescription>
        </DialogHeader>

        {settlements.length === 0 ? (
          <div className="text-center py-12">
            <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">All Settled!</h3>
            <p className="text-gray-600">Everyone has paid their fair share. No settlements needed.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {settlements.map((settlement, index) => {
              const fromPerson = people.find(p => p.id === settlement.from);
              const toPerson = people.find(p => p.id === settlement.to);

              return (
                <div key={settlement.id} className="p-4 rounded-lg border border-gray-200">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <div className="flex items-center space-x-2">
                        <Avatar className="h-10 w-10">
                          {fromPerson?.avatar ? (
                            <AvatarImage src={fromPerson.avatar} alt={fromPerson.name} />
                          ) : (
                            <AvatarFallback className={`${fromPerson?.color} text-white`}>
                              {fromPerson?.initials}
                            </AvatarFallback>
                          )}
                        </Avatar>
                        <ArrowRight className="w-5 h-5 text-gray-400" />
                        <Avatar className="h-10 w-10">
                          {toPerson?.avatar ? (
                            <AvatarImage src={toPerson.avatar} alt={toPerson.name} />
                          ) : (
                            <AvatarFallback className={`${toPerson?.color} text-white`}>
                              {toPerson?.initials}
                            </AvatarFallback>
                          )}
                        </Avatar>
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">
                          {fromPerson?.name} → {toPerson?.name}
                        </p>
                        <p className="text-sm text-gray-600">Step {index + 1} of {settlements.length}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-blue-600 mb-2">
                        ${settlement.amount.toFixed(2)}
                      </p>
                      <Button
                        size="sm"
                        onClick={() => handleMarkComplete(settlement)}
                        disabled={settlement.status === 'completed'}
                        className={`${
                          settlement.status === 'completed' 
                            ? 'bg-green-100 text-green-800 cursor-not-allowed' 
                            : 'bg-green-600 hover:bg-green-700 text-white'
                        }`}
                      >
                        {settlement.status === 'completed' ? (
                          <><CheckCircle className="w-4 h-4 mr-1" /> Completed</>
                        ) : (
                          'Mark Complete'
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// Budget Edit Modal
function BudgetEditModal({ open, onOpenChange, person, onSave }: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  person: Person | null;
  onSave: (personId: string, budget: number) => void;
}) {
  const [budget, setBudget] = useState(0);

  useEffect(() => {
    if (person) {
      setBudget(person.budget);
    }
  }, [person]);

  const handleSave = () => {
    if (person && budget > 0) {
      onSave(person.id, budget);
      onOpenChange(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit Budget</DialogTitle>
          <DialogDescription>
            Update budget for {person?.name}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="budget">Budget Amount</Label>
            <Input
              id="budget"
              type="number"
              step="0.01"
              value={budget}
              onChange={(e) => setBudget(parseFloat(e.target.value) || 0)}
              placeholder="0.00"
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave} className="bg-blue-600 hover:bg-blue-700 text-white">
            Save Budget
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}